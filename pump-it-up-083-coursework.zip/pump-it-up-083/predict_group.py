import json

import numpy as np
import pandas as pd

from experiment import LABELS, OUT, load_data

_, _, test = load_data()
recipe = json.loads((OUT / 'group_choice.json').read_text())
with np.load(OUT / 'test_probabilities.npz') as data:
    assert np.array_equal(data['id'], test.id.to_numpy())
    probabilities = np.stack([data[key] for key in recipe['models']], axis=1)
weights = np.array([recipe['recipe'].get(group, [.2] * 5) for group in test.waterpoint_type])
classes = np.einsum('ij,ijk->ik', weights, probabilities).argmax(axis=1)
predictions = pd.Series(np.asarray(LABELS)[classes], index=test.id)
submission = pd.read_csv(OUT / 'submission.csv')
submission['status_group'] = predictions.loc[submission.id].to_numpy()
submission.to_csv(OUT / 'submission_group.csv', index=False)
