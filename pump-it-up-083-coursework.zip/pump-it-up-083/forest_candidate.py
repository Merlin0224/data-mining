import argparse,time
import numpy as np,pandas as pd
from sklearn.ensemble import ExtraTreesClassifier,RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split,StratifiedKFold
from experiment import OUT,LABELS,SEED,load_data,prepare
from gpu_candidate import engineered

def encode(a,b):
    a,b=a.copy(),b.copy()
    for col in a.select_dtypes(exclude=np.number):
        levels=a[col].value_counts()
        lookup=pd.Series(np.arange(len(levels),dtype=float),index=levels.index)
        a[col]=a[col].map(lookup).fillna(-1)
        b[col]=b[col].map(lookup).fillna(-1)
    med=a.median().fillna(-1)
    return a.fillna(med).astype('float32'),b.fillna(med).astype('float32')

def main():
    p=argparse.ArgumentParser();p.add_argument('--fold',type=int,required=True);p.add_argument('--family',required=True);args=p.parse_args()
    X,y,_=load_data();yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    ix,jx=list(StratifiedKFold(3,shuffle=True,random_state=SEED).split(dev,yy[dev]))[args.fold]
    it,iv=dev[ix],dev[jx]
    a,b=encode(*engineered(prepare(X.iloc[it]),prepare(X.iloc[iv]),grid=True))
    start=time.perf_counter()
    if args.family=='et':
        model=ExtraTreesClassifier(n_estimators=500,min_samples_leaf=1,max_features=.7,random_state=42,n_jobs=6)
    else:
        model=RandomForestClassifier(n_estimators=450,min_samples_leaf=1,max_features=.45,random_state=42,n_jobs=6)
    model.fit(a,yy[it]);prob=model.predict_proba(b)
    print(args.family,accuracy_score(yy[iv],prob.argmax(axis=1)),time.perf_counter()-start,flush=True)
    np.savez_compressed(OUT/f'{args.family}_fold{args.fold}.npz',index=iv,target=yy[iv],**{args.family:prob})
if __name__=='__main__':main()
