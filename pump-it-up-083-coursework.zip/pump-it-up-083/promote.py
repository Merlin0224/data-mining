import argparse,itertools,json,hashlib,time,os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score,f1_score
from sklearn.model_selection import train_test_split
from experiment import BASE,OUT,LABELS,SEED,load_data,prepare,augmented
from select_eval import fit as train_core
from gpu_candidate import engineered
from forest_candidate import encode
from sklearn.ensemble import ExtraTreesClassifier,RandomForestClassifier
from catboost import CatBoostClassifier

STEMS=['','gpu_','et_','rf_','xgb17_','rfsp_','ggeo_']
def read_stem(stem):
    paths=[OUT/f'{stem}fold{i}.npz' for i in range(3)]
    if not all(p.exists() for p in paths):return
    z=[np.load(p,allow_pickle=False) for p in paths]
    kk=sorted(set.intersection(*(set(f.files) for f in z))-{'index','target'})
    return np.hstack([f['index'] for f in z]),np.hstack([f['target'] for f in z]),{k:np.vstack([f[k] for f in z]) for k in kk}

def score(y,p):return float(accuracy_score(y,p.argmax(axis=1)))
def select():
    base=read_stem('')
    ix,y,ps=base
    for stem in STEMS[1:]:
        vals=read_stem(stem)
        if vals is None:continue
        idx,labels,probs=vals
        assert np.array_equal(ix,idx) and np.array_equal(y,labels)
        ps.update(probs)
    rank=sorted(((score(y,p),k) for k,p in ps.items()),reverse=True)
    families=['cat_geo_', 'cat_raw_', 'lgb_geo_group_', 'lgb_geo_','gpu_d8_', 'gpu_d10_', 'ggeo_', 'et','rf','xgb17','rfsp']
    picked=[]
    # Keep the best checkpoint of each family, then select ensembles by OOF.
    for prefix in families:
        n=next((k for s,k in rank if (k.startswith(prefix) if prefix.endswith('_') else k==prefix)),None)
        if n:picked.append(n)
    assert len(ix)==47520 and len(np.unique(ix))==len(ix)
    scored=[(s,(k,),(1.,)) for s,k in rank]
    for n in (2,3,4,5):
        for keys in itertools.combinations(picked,n):
            weights=np.full(n,1/n)
            mixture=sum(w*ps[k] for k,w in zip(keys,weights))
            scored.append((score(y,mixture),keys,tuple(weights)))
            if n<=4:
                for i in range(n):
                    for w in [.42,.56,.70]:
                        ww=np.full(n,(1-w)/(n-1));ww[i]=w
                        q=sum(v*ps[k] for k,v in zip(keys,ww))
                        scored.append((score(y,q),keys,tuple(ww)))
    acc,keys,weights=max(scored,key=lambda z:(z[0],-len(z[1])))
    summary={'development_oof_accuracy':acc,'models':keys,'weights':weights,'single_model_oof':rank,
             'fold_families_complete':[s for s in STEMS if read_stem(s) is not None]}
    (OUT/'selected.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

def run(stage):
    s=json.loads((OUT/'selected.json').read_text())
    X,y,X_test=load_data()
    yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    raw=pd.read_csv(BASE / 'results' / 'split_assignment.csv')
    assert set(X.iloc[hold].id)==set(raw.loc[raw.split=='validation','id']) and not set(dev)&set(hold)
    train=dev if stage=='holdout' else np.arange(len(X))
    Xquery=X.iloc[hold] if stage=='holdout' else X_test
    ax,bx=X.iloc[train],Xquery
    a,b=prepare(ax),prepare(bx)
    keys=s['models']
    if any(k.startswith(('cat_','lgb_','ggeo_')) for k in keys):
        axa,bxb=augmented(a,yy[train],b)

    def fit(key):
        t=time.perf_counter()
        print('FIT',stage,key,flush=True)
        if key in ['xgb17','rfsp']:
            from reference_model import fit as ref_fit
            pred=ref_fit(ax,yy[train],bx,key)
        elif key.startswith(('cat_','lgb_')):
            pred=train_core(axa,bxb,yy[train],key,stage)
        elif key.startswith('ggeo_'):
            from geo_gpu2 import fit as geo_fit
            mod=geo_fit(axa,yy[train],bxb,num=int(key.rsplit('_',1)[1]),model_path=OUT/f'{stage}_{key}.cbm')
            pred=mod.predict_proba(bxb)
        elif key.startswith('gpu_'):
            depth=int(key.split('_')[1][1:])
            u,v=engineered(a,b,grid=depth==10)
            cat=u.select_dtypes(exclude=np.number).columns.tolist()
            mod=CatBoostClassifier(task_type='GPU',devices='0',gpu_ram_part=.24,
                depth=depth,iterations=int(key.rsplit('_',1)[1]),learning_rate=.035,l2_leaf_reg=6,
                random_seed=42,verbose=False,allow_writing_files=False,thread_count=5,
                loss_function='MultiClass',cat_features=cat,max_ctr_complexity=2,border_count=64)
            mod.fit(u,yy[train])
            mod.save_model(str(OUT/f'{stage}_{key}.cbm'))
            pred=mod.predict_proba(v)
        else:
            assert key in ['et','rf']
            u,v=encode(*engineered(a,b,grid=True))
            if key=='et':
                mod=ExtraTreesClassifier(n_estimators=500,min_samples_leaf=1,max_features=.7,random_state=42,n_jobs=6)
            else:
                mod=RandomForestClassifier(n_estimators=450,min_samples_leaf=1,max_features=.45,random_state=42,n_jobs=6)
            mod.fit(u,yy[train]);pred=mod.predict_proba(v)
        print('FINISHED',stage,key,round(time.perf_counter()-t,1),flush=True)
        return pred
    with ThreadPoolExecutor(max_workers=3) as pool:
        probabilities=list(pool.map(fit, keys))
    prob=sum(w*p for w,p in zip(s['weights'],probabilities))
    assert np.isfinite(prob).all() and np.allclose(prob.sum(axis=1),1,atol=2e-6)
    pred=prob.argmax(1)
    np.savez_compressed(OUT/f'{stage}_probabilities.npz',id=Xquery.id.to_numpy(),probability=prob,**dict(zip(keys,probabilities)))
    if stage=='holdout':
        audit={'accuracy':score(yy[hold],prob),'macro_f1':float(f1_score(yy[hold],pred,average='macro')),
               'sample_count':len(hold),'correct':int(np.sum(yy[hold]==pred)),
               'selection':s,'single_model_holdout':{k:score(yy[hold],q) for k,q in zip(keys,probabilities)},
               'classification_report':classification_report(yy[hold],pred,target_names=LABELS,output_dict=True),
               'confusion_matrix':confusion_matrix(yy[hold],pred).tolist()}
        pd.DataFrame({'id':Xquery.id.to_numpy(),'actual':np.array(LABELS)[yy[hold]],'prediction':np.array(LABELS)[pred]}).to_csv(OUT/'validation_predictions.csv',index=False)
        (OUT/'holdout_metrics.json').write_text(json.dumps(audit,indent=2))
        print(json.dumps(audit,indent=2))
    else:
        template=pd.read_csv(BASE / 'data' / 'raw' / 'SubmissionFormat.csv')
        q=pd.DataFrame({'id':Xquery.id.to_numpy(),'status_group':np.array(LABELS)[pred]}).set_index('id').loc[template.id].reset_index()
        assert len(q)==14850 and q.id.tolist()==template.id.tolist()
        q.to_csv(OUT/'submission.csv',index=False)
        print(hashlib.sha256((OUT/'submission.csv').read_bytes()).hexdigest())
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['select','holdout','test']);a=ap.parse_args()
    if a.stage=='select':select()
    else:run(a.stage)
