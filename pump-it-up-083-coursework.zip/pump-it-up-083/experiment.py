"""Develop improved spatial classifiers without using holdout labels in fitting."""
import argparse, json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.neighbors import BallTree
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import accuracy_score, f1_score
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from pump_model import PumpFeatures, load_data, SEED, LABELS
OUT=Path(__file__).resolve().parent
THREADS=6
PAIR_KEYS=[('ward','quantity'),('ward','waterpoint_type'),('ward','extraction_type'),
           ('district_key','quantity'),('lga','source'),('lga','installer'),('lga','scheme_name'),
           ('subvillage','quantity'),('scheme_name','quantity'),('installer','construction_year'),
           ('funder','payment'),('waterpoint_type','quantity'),('region','recorded_year'),
           ('construction_year','extraction_type'),('basin','source'),('management','payment')]
CAT_SETTINGS=dict(iterations=1350,depth=8,learning_rate=.065,thread_count=THREADS,
                  loss_function='MultiClass',random_seed=SEED,verbose=False,allow_writing_files=False)
LGB_SETTINGS=dict(n_estimators=1700, learning_rate=.032,num_leaves=63,min_child_samples=19,
                  max_bin=127,reg_lambda=2.0,colsample_bytree=.82,subsample=.85,subsample_freq=1,
                  cat_smooth=14,cat_l2=12,n_jobs=THREADS,random_state=SEED,verbosity=-1)
CHECKPOINTS={'cat':[800,1100,1350],'lgb':[850,1250,1700]}
SETS=['geo','geo_group','raw']

def prepare(X):
    f=PumpFeatures().fit_transform(X).reset_index(drop=True)
    for name in ['wpt_name','scheme_name','extraction_type_group','extraction_type_class',
                 'payment_type','quality_group','source_type','waterpoint_type_group']:
        val=X[name].reset_index(drop=True).astype('string').str.lower().str.strip()
        f[name]=val.fillna('__missing__').astype(str)
    for name in ['installer','funder','scheme_name','wpt_name','subvillage']:
        f[name+'_clean']=f[name].str.replace(r'[^a-z0-9]+','',regex=True).replace('','__missing__')
    dates=pd.to_datetime(X.date_recorded.reset_index(drop=True),errors='coerce')
    f['survey_day']=(dates-pd.Timestamp('2000-01-01')).dt.days.astype(float)
    f['survey_week']=f['survey_day']//7
    f['operating_year_decade']=np.floor(f['construction_year']/10)
    f['coordinate_precision_lat']=np.abs(f.latitude*1000-np.round(f.latitude*1000))
    f['coordinate_precision_lon']=np.abs(f.longitude*1000-np.round(f.longitude*1000))
    for s in (10, 30, 100, 300):
        x=(f.longitude*s).round().astype('Int64').astype('string')
        y=(f.latitude*s).round().astype('Int64').astype('string')
        f[f'grid_{s}']=(x+'_'+y).fillna('__missing__').astype(str)
    for a,b in PAIR_KEYS:
        f[f'pair_{a}_{b}']=f[a].astype(str)+'|'+f[b].astype(str)
    return f

def groups(ref, y, query):
    prior=np.bincount(y,minlength=3)/len(y)
    onehot=np.eye(3,dtype=np.float32)[y]
    cols={}
    for k in ref.select_dtypes(exclude=np.number).columns:
        stats=pd.DataFrame(onehot).groupby(ref[k].to_numpy(),sort=False).sum()
        hit=stats.reindex(query[k].to_numpy(),fill_value=0).to_numpy()
        count=hit.sum(axis=1)
        pp=(hit+prior*6)/(count[:,None]+6)
        cols[f'enc_{k}_n']=np.log1p(count)
        for l in range(3):cols[f'enc_{k}_{l}']=pp[:,l]
    return pd.DataFrame(cols,dtype='float32')

def geo(ref, y, query):
    prior=np.bincount(y,minlength=3)/len(y)
    result={}
    ref_xy=ref[['latitude','longitude']].to_numpy()
    query_xy=query[['latitude','longitude']].to_numpy()
    good_ref=np.isfinite(ref_xy).all(axis=1)
    good_query=np.isfinite(query_xy).all(axis=1)
    ri=np.flatnonzero(good_ref); qi=np.flatnonzero(good_query)
    if not len(ri):raise ValueError('No spatial reference points')
    tree=BallTree(np.deg2rad(ref_xy[ri]),metric='haversine')
    dd,j=tree.query(np.deg2rad(query_xy[qi]),k=min(64,len(ri)))
    dist=dd*6371.0
    near=ri[j]
    labels=y[near]
    def put(key,vals,default=np.nan):
        a=np.full(len(query),default,dtype='float32');a[qi]=vals
        result[key]=a
    for k in [1,3,8,16,32,64]:
        d=dist[:,:k]; yy=labels[:,:k]
        put(f'geo_dist{k}',np.log1p(d[:,-1]))
        weight=(d+.025)**-.65
        for l in range(3):
            m=(yy==l)
            put(f'geo_class{k}_{l}',m.mean(axis=1),prior[l])
            if k in [8,32,64]:
                put(f'geo_weight{k}_{l}',(m*weight).sum(axis=1)/weight.sum(axis=1),prior[l])
    for l in range(3):
        nearest=np.where(labels==l,dist,np.inf).min(axis=1)
        put(f'geo_nearest_{l}',np.log1p(np.minimum(nearest,1000)))
    for radi in [.15,.6,2.0,6.0]:
        include=dist<=radi
        num=include.sum(axis=1)
        put(f'geo_n_{radi}',num,0)
        for l in range(3):
            put(f'geo_radius_{radi}_{l}',((include&(labels==l)).sum(axis=1)+prior[l]*1.5)/(num+1.5),prior[l])
    for key in ['quantity','waterpoint_type','extraction_type','payment','source','management','scheme_name','ward']:
        val=ref[key].to_numpy()
        same=val[near]==query[key].to_numpy()[qi,None]
        n=same.sum(axis=1)
        weight=same*(dist+.025)**-.65
        denom=weight.sum(axis=1)
        put(f'geo_same_{key}_n',n,0)
        for l in range(3):
            hit=(labels==l)
            put(f'geo_same_{key}_{l}',((weight*hit).sum(axis=1)+.3*prior[l])/(denom+.3),prior[l])
        put(f'geo_same_nn_{key}',np.log1p(np.minimum(np.where(same,dist,np.inf).min(axis=1),1000)))
    return pd.DataFrame(result)

def augmented(ref,y,query):
    # Cross-fit training target features. Transform external rows using all
    # training reference labels, without ever reading the external labels.
    parts=[]
    for src,dst in StratifiedKFold(5,shuffle=True,random_state=151).split(ref,y):
        r,q=ref.iloc[src],ref.iloc[dst]
        new=pd.concat([geo(r,y[src],q),groups(r,y[src],q)],axis=1)
        new.index=dst
        parts.append(new)
    tr=pd.concat(parts).sort_index()
    ev=pd.concat([geo(ref,y,query),groups(ref,y,query)],axis=1)
    return pd.concat([ref.reset_index(drop=True),tr],axis=1), pd.concat([query.reset_index(drop=True),ev],axis=1)

def variant(train, val, feature_set):
    def retained(name):
        if feature_set=='geo_group':return True
        if feature_set=='geo':return not name.startswith(('enc_','pair_'))
        return not name.startswith(('enc_','pair_','geo_'))
    cols=[c for c in train if retained(c)]
    return train[cols].copy(),val[cols].copy()

def model_probs(train,y,val,kind,feature_set):
    tr,va=variant(train,val,feature_set)
    cat=tr.select_dtypes(exclude=np.number).columns.tolist()
    if kind=='cat':
        model=CatBoostClassifier(cat_features=cat,**CAT_SETTINGS).fit(tr,y)
        return {f'{kind}_{feature_set}_{n}':model.predict_proba(va,ntree_end=n,thread_count=THREADS) for n in CHECKPOINTS[kind]}
    for c in cat:
        levels=pd.Index(tr[c].unique())
        tr[c]=pd.Categorical(tr[c],categories=levels)
        va[c]=pd.Categorical(va[c],categories=levels)
    model=LGBMClassifier(**LGB_SETTINGS).fit(tr,y,categorical_feature=cat)
    return {f'{kind}_{feature_set}_{n}':model.predict_proba(va,num_iteration=n) for n in CHECKPOINTS[kind]}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--fold',type=int,required=True)
    args=p.parse_args()
    X, y, _=load_data()
    yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    folds=list(StratifiedKFold(3,shuffle=True,random_state=SEED).split(dev,yy[dev]))
    a,b=folds[args.fold]
    ix,trix=dev[b],dev[a]
    started=time.perf_counter()
    tr,va=augmented(prepare(X.iloc[trix]),yy[trix],prepare(X.iloc[ix]))
    print('FEATURES',args.fold,tr.shape,va.shape,round(time.perf_counter()-started,1),flush=True)
    probs={}
    for family,s in [('lgb','geo_group'),('lgb','geo'),('cat','geo'),('cat','raw')]:
        t=time.perf_counter()
        result=model_probs(tr,yy[trix],va,family,s)
        probs.update(result)
        print(family,s,{k:round(accuracy_score(yy[ix],v.argmax(axis=1)),6) for k,v in result.items()},
              'seconds',round(time.perf_counter()-t,1),flush=True)
        np.savez_compressed(OUT/f'fold{args.fold}.npz',index=ix,target=yy[ix],**probs)
if __name__=='__main__':main()
