"""Replay a published deep XGBoost representation on the course split."""
import argparse,time
import numpy as np,pandas as pd
from sklearn.model_selection import train_test_split,StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from experiment import OUT,SEED,LABELS,load_data
from feature_engineering import EXPECTED_SOURCE_FEATURES
from top_common_identity_evaluation import make_top_common_identity_preprocessor
from spatial_height_imputation_evaluation import make_spatial_height_preprocessor

def fit(a,y,b,kind):
    if kind=='xgb17':
        pipe=make_top_common_identity_preprocessor()
        model=XGBClassifier(n_estimators=600,max_depth=17,learning_rate=.02,subsample=.8,
          colsample_bytree=.50,min_child_weight=1,reg_lambda=1,tree_method='hist',
          objective='multi:softprob',num_class=3,random_state=20260824,n_jobs=7,max_bin=256)
    else:
        pipe=make_spatial_height_preprocessor()
        model=RandomForestClassifier(n_estimators=520,max_features='sqrt',min_samples_leaf=1,
                                      random_state=42,n_jobs=7)
    tr=pipe.fit_transform(a.loc[:,list(EXPECTED_SOURCE_FEATURES)],y)
    va=pipe.transform(b.loc[:,list(EXPECTED_SOURCE_FEATURES)])
    model.fit(tr,y)
    return model.predict_proba(va)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--fold',type=int,required=True)
    p.add_argument('--kind',choices=['xgb17','rfsp'],required=True)
    args=p.parse_args()
    X,y,test=load_data()
    yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    i,j=list(StratifiedKFold(3,shuffle=True,random_state=SEED).split(dev,yy[dev]))[args.fold]
    a,b=dev[i],dev[j]
    t=time.perf_counter()
    pred=fit(X.iloc[a],yy[a],X.iloc[b],args.kind)
    print(args.kind,accuracy_score(yy[b],pred.argmax(axis=1)),round(time.perf_counter()-t,1),flush=True)
    np.savez_compressed(OUT/f'{args.kind}_fold{args.fold}.npz',index=b,target=yy[b],**{args.kind:pred})
