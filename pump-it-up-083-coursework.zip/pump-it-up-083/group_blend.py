"""Learn shrunk model weights per water-quantity category using development OOF only."""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from sklearn.metrics import f1_score
from experiment import OUT,LABELS,load_data
from promote import read_stem
keys=['cat_geo_800','cat_raw_1350','et','rf','xgb17']
X,y,T=load_data(); y=pd.Categorical(y,categories=LABELS).codes
ix,yt,allp=read_stem('')
for stem in ['et_','rf_','xgb17_']:
    ii,tt,v=read_stem(stem);assert np.array_equal(ix,ii) and np.array_equal(yt,tt)
    allp.update(v)
P=np.stack([allp[k] for k in keys]); baseline=P.mean(0)
assert np.array_equal(y[ix],yt)
rng=np.random.default_rng(921)
# Regularize choices toward the existing uniform weights for small groups.
weights=np.vstack([np.full(5,.2), rng.dirichlet(np.full(5,3),180)])
fold=np.repeat(np.arange(3),[len(np.load(OUT/f'fold{i}.npz')['index']) for i in range(3)])
def fit_apply(qref,yref,pref,query,pquery,shrink):
    out=pquery.mean(0)
    recipe={}
    for g in np.unique(qref):
        a=qref==g; b=query==g
        base=(pref[:,a].mean(0).argmax(1)==yref[a]).sum()
        sub=np.ascontiguousarray(pref[:,a,:],dtype='float32')
        penalty=shrink*np.square(weights-.2).sum(1)
        obj=np.array([(np.einsum('i,ijk->jk',w.astype('float32'),sub).argmax(1)==yref[a]).sum() for w in weights])-penalty
        k=int(obj.argmax());w=weights[k]
        out[b]=np.einsum('i,ijk->jk',w,pquery[:,b,:])
        recipe[str(g)]=w.tolist()
    return out,recipe
sections={'quantity':X.quantity.to_numpy(),'waterpoint_type':X.waterpoint_type.to_numpy(),
  'region':X.region.to_numpy(),'gps_known':np.where(X.longitude.abs()>.1,'known','missing')}
variants=[]
for field,arr in sections.items():
    q=arr[ix]
    for shrink in [30,100]:
        out=np.zeros_like(baseline)
        for i in range(3):
            a=fold!=i;b=fold==i
            out[b],_=fit_apply(q[a],yt[a],P[:,a,:],q[b],P[:,b,:],shrink)
        variants.append((float((out.argmax(1)==yt).mean()),field,shrink))
v,field,shrink=max(variants)
q=sections[field][ix]
_,recipe=fit_apply(q,yt,P,q,P,shrink)
selection={'variants':variants,'winning_field':field,'shrink':shrink,'meta_cv':v,'recipe':recipe,'models':keys}
(OUT/'group_choice.json').write_text(json.dumps(selection,indent=2))
def apply(df,pp):
    group=np.where(df.longitude.abs()>.1,'known','missing') if field=='gps_known' else df[field].to_numpy()
    return np.asarray([np.dot(recipe.get(str(g),[.2]*5),pi) for g,pi in zip(group,pp.transpose(1,0,2))])
h=np.load(OUT/'holdout_probabilities.npz')
rows=X.reset_index().set_index('id').loc[h['id'],'index'].to_numpy()
assert not set(rows)&set(ix) and len(rows)==11880
hp=np.stack([h[k] if k in h.files else np.load(OUT/f'side_{k}.npy') for k in keys])
old=hp.mean(0).argmax(1);assert (old==y[rows]).sum()==9769
pr=apply(X.iloc[rows],hp).argmax(1);ok=pr==y[rows]
result={'accuracy':ok.mean(),'macro_f1':f1_score(y[rows],pr,average='macro'),'correct':int(ok.sum()),'fixed':int((ok&(old!=y[rows])).sum()),'regressed':int((~ok&(old==y[rows])).sum()),'selection':selection}
(OUT/'group_result.json').write_text(json.dumps(result,indent=2));print(field,shrink,v,result['correct'],result['accuracy'])
