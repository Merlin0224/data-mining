import argparse, time
from concurrent.futures import ThreadPoolExecutor
import numpy as np,pandas as pd
from sklearn.model_selection import train_test_split,StratifiedKFold
from sklearn.neighbors import BallTree
from sklearn.metrics import accuracy_score
from catboost import CatBoostClassifier
from experiment import OUT,LABELS,SEED,load_data, prepare

def engineered(ref,q,grid):
    a,b=ref.copy(),q.copy()
    # All count tables and spatial descriptors use only training covariates.
    for col in a.select_dtypes(exclude=np.number):
        if col.startswith('pair_') or (col.startswith('grid_') and not grid):continue
        tab=a[col].value_counts()
        a[f'freq_{col}']=np.log1p(a[col].map(tab).fillna(0)).astype('float32')
        b[f'freq_{col}']=np.log1p(b[col].map(tab).fillna(0)).astype('float32')
    ar=ref[['latitude','longitude']].to_numpy()
    ar_ok=np.isfinite(ar).all(axis=1)
    height=ref.gps_height.to_numpy()
    yr=ref.construction_year.to_numpy()
    for label,val,valid in [('height',height,ar_ok&(height!=0)&np.isfinite(height)),('built',yr,ar_ok&np.isfinite(yr))]:
        tree=BallTree(np.deg2rad(ar[valid]),metric='haversine')
        for t in (a,b):
            coord=t[['latitude','longitude']].to_numpy()
            ind=np.flatnonzero(np.isfinite(coord).all(axis=1))
            ds,neigh=tree.query(np.deg2rad(coord[ind]),k=12)
            vals=val[valid][neigh]
            for n in [3,12]:
                w=1/(.03+6371*ds[:,:n])
                value=(vals[:,:n]*w).sum(axis=1)/w.sum(axis=1)
                t.loc[ind,f'spatial_{label}_{n}']=value
                t.loc[ind,f'spatial_{label}_std{n}']=np.std(vals[:,:n],axis=1)
    cols=[k for k in a if not k.startswith('pair_') and (grid or not k.startswith('grid_'))]
    return a[cols],b[cols]

def main():
    p=argparse.ArgumentParser();p.add_argument('--fold',type=int,required=True);args=p.parse_args()
    X,y,_=load_data();yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    a,b=list(StratifiedKFold(3,shuffle=True,random_state=SEED).split(dev,yy[dev]))[args.fold]
    ix,jx=dev[a],dev[b]
    train,query=prepare(X.iloc[ix]),prepare(X.iloc[jx])
    pr={}
    for depth,grid in [(8,False),(10,True)]:
        a,b=engineered(train,query,grid)
        categorical=a.select_dtypes(exclude=np.number).columns.tolist()
        started=time.perf_counter()
        m=CatBoostClassifier(task_type='GPU',devices='0', gpu_ram_part=.30,
            depth=depth,iterations=2500,learning_rate=.035,l2_leaf_reg=6,
            random_seed=42,verbose=False,allow_writing_files=False,thread_count=5,
            loss_function='MultiClass',cat_features=categorical,
            max_ctr_complexity=2,border_count=64)
        m.fit(a,yy[ix])
        for n in [1200,1800,2500]:
            P=m.predict_proba(b,ntree_end=n);name=f'gpu_d{depth}_{n}'
            pr[name]=P
            print(name,accuracy_score(yy[jx],P.argmax(axis=1)),flush=True)
        print('seconds',time.perf_counter()-started,flush=True)
        np.savez_compressed(OUT/f'gpu_fold{args.fold}.npz',index=jx,target=yy[jx],**pr)
if __name__=='__main__':main()
