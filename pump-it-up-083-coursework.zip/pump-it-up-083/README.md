# Pump it Up · 数据挖掘大作业

DrivenData 首次提交公开榜准确率 **0.8313**。固定验证集准确率 **0.822896**（9,776 / 11,880），Macro-F1 **0.698145**。

模型组合包含两套 CatBoost、Extra Trees、Random Forest 和 XGBoost，按水泵类型混合五组预测概率。小样本分组的权重向均匀权重收缩。模型使用官方数据。

## 复现

在仓库根目录按主 README 准备官方数据。安装仓库依赖及 `xgboost`，并把参考实验的 Python 源码目录加入 `PYTHONPATH`。参考预处理的导入点在 `reference_model.py`，包含 `feature_engineering`、`top_common_identity_evaluation` 和 `spatial_height_imputation_evaluation`。参考方法见 [Anthony Watts 的实验说明](https://www.anthonypwatts.co.uk/projects/pump-it-up/)。

```sh
python pump-it-up-083/promote.py test
python pump-it-up-083/predict_group.py
```

脚本先读取 `selected.json`，用全部官方训练样本训练五个基模型，再使用已确定的 `group_choice.json` 生成 `submission_group.csv`。验证明细见 `group_result.json`。
