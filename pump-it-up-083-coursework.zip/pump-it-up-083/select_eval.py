"""Select by development OOF accuracy, then evaluate the untouched holdout."""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score,classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from experiment import LABELS, SEED, load_data, prepare, augmented, variant, OUT, THREADS, LGB_SETTINGS, CAT_SETTINGS
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier

def score(y,p):
    return float(accuracy_score(y,p.argmax(axis=1)))
def select():
    folds=[np.load(OUT/f'fold{i}.npz',allow_pickle=False) for i in range(3)]
    choices=sorted(set.intersection(*(set(f.files) for f in folds))-{'index','target'})
    y=np.hstack([f['target'] for f in folds])
    index=np.hstack([f['index'] for f in folds])
    assert len(np.unique(index))==len(index)==47520
    ps={k:np.vstack([f[k] for f in folds]) for k in choices}
    results=sorted([(score(y,p),k) for k,p in ps.items()],reverse=True)
    candidates=[(s,(k,),(1.,)) for s,k in results]
    picks=[next((k for _,k in results if k.startswith(prefix)), None)
           for prefix in ['cat_geo_','lgb_geo_','lgb_geo_group_','cat_raw_']]
    picks=[k for k in picks if k]
    for a,b in itertools.combinations(picks,2):
        for w in [.25,.50,.75]:
            candidates.append((score(y,w*ps[a]+(1-w)*ps[b]),(a,b),(w,1-w)))
    for chosen in itertools.combinations(picks,3):
        for weights in [(1/3,1/3,1/3),(.5,.25,.25),(.25,.5,.25),(.25,.25,.5)]:
            candidates.append((score(y,sum(w*ps[k] for k,w in zip(chosen,weights))),chosen,weights))
    s,keys,weights=max(candidates,key=lambda v:(v[0],-len(v[1])))
    selected={'development_oof_accuracy':s,'models':keys,'weights':weights,'single_model_oof':results}
    (OUT/'selected.json').write_text(json.dumps(selected,indent=2))
    print(json.dumps(selected,indent=2),flush=True)
    return selected

def fit(tr,va,y,key,tag):
    family,s,num=key.split('_',1)[0],key.split('_',1)[1].rsplit('_',1)[0],int(key.rsplit('_',1)[1])
    a,b=variant(tr,va,s)
    cat=a.select_dtypes(exclude=np.number).columns.tolist()
    if family=='cat':
        m=CatBoostClassifier(cat_features=cat,**(CAT_SETTINGS|{'iterations':num})).fit(a,y)
        m.save_model(str(OUT/f'{tag}_{key}.cbm'))
        return m.predict_proba(b,thread_count=THREADS)
    for c in cat:
        levels=pd.Index(a[c].unique())
        a[c]=pd.Categorical(a[c],categories=levels)
        b[c]=pd.Categorical(b[c],categories=levels)
    m=LGBMClassifier(**(LGB_SETTINGS|{'n_estimators':num})).fit(a,y,categorical_feature=cat)
    m.booster_.save_model(str(OUT/f'{tag}_{key}.txt'))
    return m.predict_proba(b)
def run(tag,selected):
    X,y,test=load_data()
    yy=pd.Categorical(y,categories=LABELS).codes
    dev,hold=train_test_split(np.arange(len(X)),test_size=.2,stratify=yy,random_state=SEED)
    original=pd.read_csv('/data/lijinyang/jobs/2026-11-24_pump_it_up_reproduction/results/split_assignment.csv')
    assert set(X.iloc[hold].id)==set(original.loc[original.split=='validation','id'])
    train=dev if tag=='holdout' else np.arange(len(X))
    query=X.iloc[hold] if tag=='holdout' else test
    tr,va=augmented(prepare(X.iloc[train]),yy[train],prepare(query))
    s=time.perf_counter()
    prob=np.zeros((len(va),3))
    for k,w in zip(selected['models'],selected['weights']):
        print('FIT',tag,k,flush=True)
        prob+=w*fit(tr,va,yy[train],k,tag)
    prediction=prob.argmax(axis=1)
    if tag=='holdout':
        metrics={'accuracy':score(yy[hold],prob),'macro_f1':float(f1_score(yy[hold],prediction,average='macro')),
                 'sample_count':len(hold),'correct':int(np.sum(yy[hold]==prediction)),
                 'classification_report':classification_report(yy[hold],prediction,target_names=LABELS,output_dict=True),
                 'confusion_matrix':confusion_matrix(yy[hold],prediction).tolist(),
                 'fit_seconds':time.perf_counter()-s,'selection':selected}
        pd.DataFrame({'id':query.id.to_numpy(),'actual':np.array(LABELS)[yy[hold]],'prediction':np.array(LABELS)[prediction]}).to_csv(OUT/'validation_predictions.csv',index=False)
        (OUT/'holdout_metrics.json').write_text(json.dumps(metrics,indent=2))
        print(json.dumps(metrics,indent=2))
    else:
        template=pd.read_csv('/data/lijinyang/jobs/2026-11-24_pump_it_up_reproduction/data/raw/SubmissionFormat.csv')
        q=pd.DataFrame({'id':query.id.to_numpy(),'status_group':np.array(LABELS)[prediction]}).set_index('id').loc[template.id].reset_index()
        assert len(q)==14850 and q.id.tolist()==template.id.tolist()
        q.to_csv(OUT/'submission.csv',index=False)
        print(hashlib.sha256((OUT/'submission.csv').read_bytes()).hexdigest())

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=['select','holdout','test'])
    t=p.parse_args().stage
    if t=='select':select()
    else:run(t,json.loads((OUT/'selected.json').read_text()))
